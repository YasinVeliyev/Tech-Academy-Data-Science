[a,b,c]=[int(i) for i in input().split()]

print(f"{2*(a*b+b*c+a*c)} {a*b*c}")
