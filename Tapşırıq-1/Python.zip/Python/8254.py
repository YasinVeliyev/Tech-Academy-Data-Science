[n,m]=[int(i) for i in input().split()]

print((n-1)*3*m)