[n,m]=[int(i) for i in input().split()]
print(f"{n//m} {n%m}")