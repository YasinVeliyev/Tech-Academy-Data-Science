hasil=1
for i in input():
    hasil*=int(i)
print(hasil)