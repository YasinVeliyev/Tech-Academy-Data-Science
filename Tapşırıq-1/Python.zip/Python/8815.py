a=int(input())

print(f"{6*a**2} {a**3}")