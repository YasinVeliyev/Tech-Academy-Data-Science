a=set(input().split())

print(len(a))