[start,end]=[int(i) for i in input().split(" ")]

print((start+end)*(end-start+1)/2)