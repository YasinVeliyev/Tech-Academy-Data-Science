layers = int(input())

print(int((2*2+(layers - 1)*2)*layers/2+1))