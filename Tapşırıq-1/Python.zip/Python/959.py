number=input()

print(f"{int(number[0])+int(number[-1])}")