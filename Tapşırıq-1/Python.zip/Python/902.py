age = int(input())
if 1 <= age <= 3:
    print("Initial")
elif 4 <= age <= 6:
    print("Average")
elif 7 <= age <= 9:
    print("Sufficient")
else:
    print("High")
